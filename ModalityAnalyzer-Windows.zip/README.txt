MODALITY ANALYZER - DESKTOP APPLICATION
========================================

Thank you for downloading the Modality Analyzer Desktop Application!

WHAT IS THIS?
This is a standalone Windows application that analyzes sentences for alethic modality - determining whether statements express necessity, possibility, or impossibility.

INSTALLATION:
No installation required! This is a portable application.

HOW TO RUN:
1. Double-click "ModalityAnalyzer.exe"
2. A small window will appear with a "Launch Application" button
3. Click "Launch Application" to open the analyzer in your web browser
4. Keep the small window open while using the application

FEATURES:
- Analyze sentences for necessity, possibility, and impossibility
- Real-time grammatical analysis with part-of-speech tagging
- Modal indicator detection
- Example sentences for quick testing
- Detailed explanations of analysis results

SYSTEM REQUIREMENTS:
- Windows 7 or later
- Any modern web browser (Chrome, Firefox, Edge, etc.)
- No internet connection required

TROUBLESHOOTING:
- If Windows shows a security warning, click "More info" then "Run anyway"
- If the application doesn't start, try running as administrator
- Make sure no antivirus software is blocking the executable

USAGE TIPS:
- Try the example sentences to see how the analyzer works
- Enter your own sentences to analyze their modality
- The application works entirely offline - no data is sent anywhere

For support or questions, visit: [Your Website URL]

Version: 1.0.0
Built with: Python + PyInstaller
License: MIT
